#pragma once
#include "MouseManager.h"
#include "AudioManager.h"
#include "OutputManager.h"
#include "ScreenCaptureManager.h"
#include "Log.h"
#include "fifo_map.h"
#include "CommonTypes.h"
typedef void(__stdcall *CallbackCompleteFunction)(std::wstring, nlohmann::fifo_map<std::wstring, int>);
typedef void(__stdcall *CallbackStatusChangedFunction)(int);
typedef void(__stdcall *CallbackErrorFunction)(std::wstring, std::wstring);
typedef void(__stdcall *CallbackSnapshotFunction)(std::wstring);
typedef void(__stdcall *CallbackFrameNumberChangedFunction)(int, INT64, _In_opt_ FRAME_BITMAP_DATA *bitmapData);
typedef void(__stdcall *CallbackNewAudioDataFunction)(_In_ FRAME_AUDIO_INFO *audioData);

constexpr auto STATUS_IDLE = 0;
constexpr auto STATUS_RECORDING = 1;
constexpr auto STATUS_PAUSED = 2;
constexpr auto STATUS_FINALIZING = 3;

constexpr auto API_DESKTOP_DUPLICATION = 0;
constexpr auto API_GRAPHICS_CAPTURE = 1;

constexpr auto MAX_FRAME_LENGTH_100_NANOS = 10'000'000;

class RecordingManager
{
public:
	RecordingManager();
	~RecordingManager();
	CallbackErrorFunction RecordingFailedCallback;
	CallbackCompleteFunction RecordingCompleteCallback;
	CallbackStatusChangedFunction RecordingStatusChangedCallback;
	CallbackSnapshotFunction RecordingSnapshotCreatedCallback;
	CallbackFrameNumberChangedFunction RecordingFrameNumberChangedCallback;
	CallbackNewAudioDataFunction RecordingNewAudioCallback;
	HRESULT TakeSnapshot(_In_ std::wstring path);
	HRESULT TakeSnapshot(_In_ IStream *stream);
	HRESULT BeginRecording(_In_ std::wstring path);
	HRESULT BeginRecording(_In_ IStream *stream);
	void EndRecording();
	void PauseRecording();
	void ResumeRecording();

	bool IsRecording() { return m_IsRecording; }

	static bool SetExcludeFromCapture(HWND hwnd, bool isExcluded);

	inline void ClearRecordingSources() {
		for each (RECORDING_SOURCE * source in m_RecordingSources)
		{
			delete source;
		}
		m_RecordingSources.clear();
	}
	inline void SetRecordingSources(std::vector<RECORDING_SOURCE> &sources)
	{
		ClearRecordingSources();
		for each (RECORDING_SOURCE source in sources)
		{
			m_RecordingSources.push_back(new RECORDING_SOURCE(source));
		}
	}
	inline const std::vector<RECORDING_SOURCE *> &GetRecordingSources() const {
		return m_RecordingSources;
	}

	inline HRESULT GetRecordingSourceForId(std::wstring id, _Outptr_ RECORDING_SOURCE **ppRecordingSource) {
		for each (RECORDING_SOURCE * nativeSource in GetRecordingSources())
		{
			if (nativeSource->ID == id) {
				*ppRecordingSource = nativeSource;
				return S_OK;
			}
		}
		return E_FAIL;
	}

	inline void ClearOverlays() {
		for each (RECORDING_OVERLAY * overlay in m_Overlays)
		{
			delete overlay;
		}
		m_Overlays.clear();
	}
	inline void SetOverlays(std::vector<RECORDING_OVERLAY> &overlays) {
		ClearOverlays();
		for each (RECORDING_OVERLAY overlay in overlays)
		{
			m_Overlays.push_back(new RECORDING_OVERLAY(overlay));
		}
	}
	inline std::vector<RECORDING_OVERLAY *> &GetRecordingOverlays() {
		return m_Overlays;
	}

	inline HRESULT GetRecordingOverlayForId(std::wstring id, _Outptr_ RECORDING_OVERLAY **ppOverlay) {
		for each (RECORDING_OVERLAY * nativeOverlay in GetRecordingOverlays())
		{
			if (nativeOverlay->ID == id) {
				*ppOverlay = nativeOverlay;
				return S_OK;
			}
		}
		return E_FAIL;
	}

	inline HRESULT UpdateOverlays() {
		if (m_IsRecording) {
			return m_CaptureManager->InitializeOverlays(m_Overlays, nullptr);
		}
		return S_OK;
	}

	void SetLogEnabled(bool value);
	void SetLogFilePath(std::wstring value);
	void SetLogSeverityLevel(int value);

	void SetEncoderOptions(ENCODER_OPTIONS *options) { m_EncoderOptions.reset(options); }
	std::shared_ptr<ENCODER_OPTIONS> GetEncoderOptions() { return m_EncoderOptions; }
	void SetAudioOptions(AUDIO_OPTIONS *options) { m_AudioOptions.reset(options); }
	std::shared_ptr<AUDIO_OPTIONS> GetAudioOptions() { return m_AudioOptions; }
	void SetMouseOptions(MOUSE_OPTIONS *options) { m_MouseOptions.reset(options); }
	std::shared_ptr<MOUSE_OPTIONS> GetMouseOptions() { return m_MouseOptions; }
	void SetSnapshotOptions(SNAPSHOT_OPTIONS *options) { m_SnapshotOptions.reset(options); }
	std::shared_ptr<SNAPSHOT_OPTIONS> GetSnapshotOptions() { return m_SnapshotOptions; }
	void SetOutputOptions(OUTPUT_OPTIONS *options) { m_OutputOptions.reset(options); }
	std::shared_ptr<OUTPUT_OPTIONS> GetOutputOptions() { return m_OutputOptions; }
private:
	bool m_IsDestructing;
	UINT m_TimerResolution;
	struct TaskWrapper;
	std::unique_ptr<TaskWrapper> m_TaskWrapperImpl;

	DX_RESOURCES m_DxResources;

	std::unique_ptr<AudioManager> m_AudioManager;
	std::unique_ptr<TextureManager> m_TextureManager;
	std::unique_ptr<OutputManager> m_OutputManager;
	std::unique_ptr<ScreenCaptureManager> m_CaptureManager;
	std::unique_ptr<MouseManager> m_MouseManager;
	std::unique_ptr<TimelineManager> m_TimelineManager;
	std::unique_ptr<DynamicWait> m_DynamicWait;

	HRESULT m_EncoderResult = S_FALSE;
	HRESULT m_MfStartupResult = S_FALSE;
	std::wstring m_OutputFolder = L"";
	std::wstring m_OutputFullPath = L"";
	int m_RestartCaptureCount = 0;

	std::vector<RECORDING_SOURCE *> m_RecordingSources;
	std::vector<RECORDING_OVERLAY *> m_Overlays;
	std::atomic<bool> m_IsPaused;
	std::atomic<bool> m_IsRecording;

	std::shared_ptr<ENCODER_OPTIONS> m_EncoderOptions;
	std::shared_ptr<AUDIO_OPTIONS> m_AudioOptions;
	std::shared_ptr<MOUSE_OPTIONS> m_MouseOptions;
	std::shared_ptr<SNAPSHOT_OPTIONS> m_SnapshotOptions;
	std::shared_ptr<OUTPUT_OPTIONS> m_OutputOptions;

	ID3D11Texture2D *m_FrameDataCallbackTexture;
	D3D11_TEXTURE2D_DESC m_FrameDataCallbackTextureDesc;

	bool CheckDependencies(_Out_ std::wstring *error)  const;
	HRESULT ConfigureOutputDir(_In_ std::wstring path, _Out_ std::wstring *error);
	REC_RESULT StartRecorderLoop(_In_ const std::vector<RECORDING_SOURCE *> &sources, _In_ const std::vector<RECORDING_OVERLAY *> &overlays, _In_opt_ IStream *pStream);

	HRESULT SendNewFrameCallback(_In_ const int frameNumber, _In_ ID3D11Texture2D *pTexture);
	HRESULT TakeSnapshot(_In_opt_ std::wstring path, _In_opt_ IStream *pStream, _In_opt_ ID3D11Texture2D *pTexture = nullptr);
	HRESULT BeginRecording(_In_opt_ std::wstring path, _In_opt_ IStream *pStream);
	HRESULT PrepareAndRenderFrame(_In_ CComPtr<ID3D11Texture2D> pTextureToRender_In_, _In_opt_ FRAME_AUDIO_DATA *pAudioData, _In_opt_ std::optional<PTR_INFO> pointerInfo);
	HRESULT RestartCapture(_In_ CAPTURE_RESULT result, _In_ const std::vector<RECORDING_SOURCE *> &sources, _In_ const std::vector<RECORDING_OVERLAY *> &overlays, _In_  HANDLE hErrorEvent, _Out_opt_ RECT *videoInputFrameRect);
	bool IsAnySourcePreviewsActive();


	/// <summary>
	/// Creates adjusted source and output rects from a recording frame rect. The source rect is normalized to start on [0,0], and the output is adjusted for any cropping.
	/// </summary>
	/// <param name="outputSize">The recording output size</param>
	/// <param name="pAdjustedSourceRect">The source rect adjusted to start on [0,0] and with custom cropping if any</param>
	/// <param name="pAdjustedOutputFrameSize">The destination rect adjusted to start on [0,0] and with custom render size if any</param>
	/// <returns></returns>
	HRESULT InitializeRects(_In_ SIZE outputSize, _Out_opt_ RECT *pAdjustedSourceRect, _Out_opt_ SIZE *pAdjustedOutputFrameSize);

	/// <summary>
	/// Save texture as snapshot image.
	/// </summary>
	/// <param name="pTexture">The texture to save to a snapshot</param>
	/// <param name="snapshotPath">A file path to save the snapshot to</param>
	/// <param name="destRect">The area of the texture to save. If the texture is larger, it will be cropped to these coordinates.</param>
	/// <returns></returns>
	HRESULT SaveTextureAsVideoSnapshot(_In_ ID3D11Texture2D *pTexture, _In_ std::wstring snapshotPath, _In_ RECT destRect);
	/// <summary>
	/// Save texture as snapshot image.
	/// </summary>
	/// <param name="pTexture">The texture to save to a snapshot</param>
	/// <param name="pStream">A stream to save the snapshot to</param>
	/// <param name="destRect">The area of the texture to save. If the texture is larger, it will be cropped to these coordinates.</param>
	/// <returns></returns>
	HRESULT SaveTextureAsVideoSnapshot(_In_ ID3D11Texture2D *pTexture, _In_ IStream *pStream, _In_ RECT destRect);
	/// <summary>
	/// Save texture as snapshot image async.
	/// </summary>
	/// <param name="pTexture">The texture to save to a snapshot</param>
	/// <param name="destRect">The area of the texture to save. If the texture is larger, it will be cropped to these coordinates.</param>
	/// <returns></returns>
	void RecordingManager::SaveTextureAsVideoSnapshotAsync(_In_ ID3D11Texture2D *pTexture, _In_ std::wstring snapshotPath, _In_ RECT destRect, _In_opt_ std::function<void(HRESULT)> onCompletion);

	/// <summary>
	/// Adds overlays, mouse cursors, and texture transforms.
	/// </summary>
	/// <param name="pTexture">The texture to process</param>
	/// <param name="pPtrInfo">Mouse pointer info (optional).</param>
	/// <param name="ppProcessedTexture">The output texture.</param>
	/// <returns>S_OK if any processing has been done, S_FALSE if no changes, else an error code</returns>
	HRESULT ProcessTexture(_In_ ID3D11Texture2D *pTexture, _Out_ ID3D11Texture2D **ppProcessedTexture, _In_opt_ std::optional<PTR_INFO> pPtrInfo);

	/// <summary>
	/// Perform cropping and resizing on texture if needed.
	/// </summary>
	/// <param name="pTexture">The texture to process</param>
	/// <param name="ppProcessedTexture">The output texture. If no transformations are done, the original texture is returned.</param>
	/// <param name="videoInputFrameRect">The source rectangle. The texture will be cropped to these coordinates if larger.</param>
	/// <param name="videoOutputFrameSize">The output dimensions. The texture will be resized to these coordinates if differing.</param>
	/// <returns>S_OK if any processing has been done, S_FALSE if no changes, else an error code</returns>
	HRESULT ProcessTextureTransforms(_In_ ID3D11Texture2D *pTexture, _Out_ ID3D11Texture2D **ppProcessedTexture, RECT videoInputFrameRect, SIZE videoOutputFrameSize);

	/// <summary>
	/// Releases DirectX resources and reports any leaks
	/// </summary>
	void CleanupDxResources();

	/// <summary>
	///	Calls the RecordingComplete or RecordingFailed callbacks depending on the success of the recording result.
	/// </summary>
	/// <param name="result">The recording result.</param>
	/// <param name="frameDelays">A map of paths to saved frames with corresponding delay between them. Only used for Slideshow mode.</param>
	void SetRecordingCompleteStatus(_In_ REC_RESULT result, _In_ std::optional<nlohmann::fifo_map<std::wstring, int>> frameDelays = std::nullopt);
};