#include "OutputManager.h"
#include "screengrab.h"
#include <ppltasks.h> 
#include <concrt.h>
#include <filesystem>
#include "LogMediaType.h"
using namespace std;
using namespace concurrency;

OutputManager::OutputManager() :
	m_Device(nullptr),
	m_DeviceContext(nullptr),
	m_CallBack(nullptr),
	m_FinalizeEvent(nullptr),
	m_SinkWriter(nullptr),
	m_OutStream(nullptr),
	m_EncoderOptions(nullptr),
	m_AudioOptions(nullptr),
	m_SnapshotOptions(nullptr),
	m_OutputOptions(nullptr),
	m_VideoStreamIndex(0),
	m_AudioStreamIndex(0),
	m_OutputFolder(L""),
	m_OutputFullPath(L""),
	m_TimelineManager(nullptr),
	m_MediaTransform(nullptr),
	m_DeviceManager(nullptr),
	m_ResetToken(0),
	m_UseManualNV12Converter(false)
{
	m_FinalizeEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
	InitializeCriticalSection(&m_CriticalSection);
}

OutputManager::~OutputManager()
{
	CloseHandle(m_FinalizeEvent);
	m_FinalizeEvent = nullptr;
	DeleteCriticalSection(&m_CriticalSection);
}

HRESULT OutputManager::Initialize(
	_In_ ID3D11DeviceContext *pDeviceContext,
	_In_ ID3D11Device *pDevice,
	_In_ TimelineManager *pTimelineManager,
	_In_ std::shared_ptr<ENCODER_OPTIONS> &pEncoderOptions,
	_In_ std::shared_ptr<AUDIO_OPTIONS> pAudioOptions,
	_In_ std::shared_ptr<SNAPSHOT_OPTIONS> pSnapshotOptions,
	_In_ std::shared_ptr<OUTPUT_OPTIONS> pOutputOptions)
{
	EnterCriticalSection(&m_CriticalSection);
	LeaveCriticalSectionOnExit leaveOnExit(&m_CriticalSection);

	m_DeviceContext = pDeviceContext;
	m_Device = pDevice;
	m_EncoderOptions = pEncoderOptions;
	m_AudioOptions = pAudioOptions;
	m_SnapshotOptions = pSnapshotOptions;
	m_OutputOptions = pOutputOptions;
	m_TimelineManager = pTimelineManager;

	if (!m_DeviceManager) {
		RETURN_ON_BAD_HR(MFCreateDXGIDeviceManager(&m_ResetToken, &m_DeviceManager));
	}
	if (m_SinkWriter) {
		m_SinkWriter->Flush(m_VideoStreamIndex);
	}
	if (m_MediaTransform) {
		m_MediaTransform->ProcessMessage(MFT_MESSAGE_COMMAND_FLUSH, 0);
	}

	RETURN_ON_BAD_HR(m_DeviceManager->ResetDevice(pDevice, m_ResetToken));
	return S_OK;
}

HRESULT OutputManager::BeginRecording(_In_ std::wstring outputPath, _In_ SIZE videoOutputFrameSize)
{
	HRESULT hr = S_FALSE;
	m_OutputFullPath = outputPath;
	if (outputPath.empty()) {
		LOG_ERROR("Failed to start recording due to output path parameter being empty");
		return E_INVALIDARG;
	}
	std::filesystem::path filePath = outputPath;
	m_OutputFolder = filePath.has_extension() ? filePath.parent_path().wstring() : filePath.wstring();
	ResetEvent(m_FinalizeEvent);

	if (GetOutputOptions()->GetRecorderMode() == RecorderModeInternal::Video) {
		if (m_FinalizeEvent) {
			m_CallBack.Attach(new (std::nothrow)CMFSinkWriterCallback(m_FinalizeEvent, nullptr));
		}
		CComPtr<IStream> pStream = nullptr;
		HRESULT hr = SHCreateStreamOnFileEx(
			outputPath.c_str(),
			STGM_READWRITE | STGM_SHARE_EXCLUSIVE,
			FILE_ATTRIBUTE_NORMAL,
			TRUE,
			nullptr,
			&pStream
		);
		RECT inputMediaFrameRect = RECT{ 0,0,videoOutputFrameSize.cx,videoOutputFrameSize.cy };
		CComPtr<IMFByteStream> mfByteStream = nullptr;
		RETURN_ON_BAD_HR(hr = MFCreateMFByteStreamOnStream(pStream, &mfByteStream));
		RETURN_ON_BAD_HR(hr = InitializeVideoSinkWriter(mfByteStream, inputMediaFrameRect, videoOutputFrameSize, DXGI_MODE_ROTATION_UNSPECIFIED, m_CallBack, &m_SinkWriter, &m_VideoStreamIndex, &m_AudioStreamIndex));
	}
	GetTimelineManager()->StartMediaClock();
	LOG_DEBUG("Sink Writer initialized");
	return hr;
}

HRESULT OutputManager::BeginRecording(_In_ IStream *pStream, _In_ SIZE videoOutputFrameSize)
{
	HRESULT hr = S_FALSE;
	if (pStream == nullptr) {
		LOG_ERROR("Failed to start recording due to output stream parameter being NULL");
		return E_INVALIDARG;
	}
	m_OutStream = pStream;
	ResetEvent(m_FinalizeEvent);
	if (GetOutputOptions()->GetRecorderMode() == RecorderModeInternal::Video) {
		CComPtr<IMFByteStream> mfByteStream = nullptr;
		RETURN_ON_BAD_HR(hr = MFCreateMFByteStreamOnStream(pStream, &mfByteStream));

		if (m_FinalizeEvent) {
			m_CallBack.Attach(new (std::nothrow)CMFSinkWriterCallback(m_FinalizeEvent, nullptr));
		}
		RECT inputMediaFrameRect = RECT{ 0,0,videoOutputFrameSize.cx,videoOutputFrameSize.cy };
		RETURN_ON_BAD_HR(hr = InitializeVideoSinkWriter(mfByteStream, inputMediaFrameRect, videoOutputFrameSize, DXGI_MODE_ROTATION_UNSPECIFIED, m_CallBack, &m_SinkWriter, &m_VideoStreamIndex, &m_AudioStreamIndex));
	}
	GetTimelineManager()->StartMediaClock();
	LOG_DEBUG("Sink Writer initialized");
	return hr;
}

HRESULT OutputManager::FinalizeRecording()
{
	LOG_INFO("Cleaning up resources");
	LOG_INFO("Finalizing recording");
	HRESULT finalizeResult = S_OK;
	if (m_SinkWriter) {

		finalizeResult = m_SinkWriter->Finalize();
		if (SUCCEEDED(finalizeResult) && m_FinalizeEvent) {
			WaitForSingleObject(m_FinalizeEvent, INFINITE);
		}
		if (FAILED(finalizeResult)) {
			LOG_ERROR("Failed to finalize sink writer");
		}
		//Dispose of MPEG4MediaSink 
		IMFMediaSink *pSink;
		if (SUCCEEDED(m_SinkWriter->GetServiceForStream(MF_SINK_WRITER_MEDIASINK, GUID_NULL, IID_PPV_ARGS(&pSink)))) {
			//Release the sink writer before calling Shutdown on the media sink. 
			//https://learn.microsoft.com/en-us/windows/win32/api/mfreadwrite/nf-mfreadwrite-mfcreatesinkwriterfrommediasink
			m_SinkWriter.Release();
			finalizeResult = pSink->Shutdown();
			SafeRelease(&pSink);
			if (FAILED(finalizeResult)) {
				LOG_ERROR("Failed to shut down IMFMediaSink");
			}
			else {
				LOG_DEBUG("Shut down IMFMediaSink");
			}
		};
		if (!m_OutputFullPath.empty()) {
			bool isFileAvailable = false;
			for (int i = 0; i < 10; i++) {
				isFileAvailable = IsFileAvailableForReading(m_OutputFullPath);
				if (isFileAvailable) {
					LOG_TRACE(L"Output file is ready");
					break;
				}
				else {
					Sleep(100);
					LOG_TRACE(L"Output file is still locked for reading, waiting..");
				}
			}
			if (!isFileAvailable) {
				LOG_WARN("Output file is still locked after maximum retries");
			}
		}
	}
	GetTimelineManager()->StopMediaClock();
	return finalizeResult;
}

HRESULT OutputManager::RenderFrame(_In_ const FrameWriteModel &model) {
	HRESULT hr(S_OK);
	EnterCriticalSection(&m_CriticalSection);
	LeaveCriticalSectionOnExit leaveOnExit(&m_CriticalSection);
	MeasureExecutionTime measure(L"RenderFrame");
	auto recorderMode = GetOutputOptions()->GetRecorderMode();

	if (recorderMode == RecorderModeInternal::Video) {
		hr = WriteFrameToVideo(model.VideoStartPos, model.VideoDuration, m_VideoStreamIndex, model.Frame);
		bool wroteAudioSample = false;
		if (FAILED(hr)) {
			_com_error err(hr);
			LOG_ERROR(L"Writing of video frame with start pos %lld ms failed: %s", (HundredNanosToMillis(model.VideoStartPos)), err.ErrorMessage());
			return hr;//Stop recording if we fail
		}

		if (model.Audio.size() > 0) {
			hr = WriteAudioSamplesToVideo(model.AudioStartPos, model.AudioDuration, m_AudioStreamIndex, model.Audio.data(), (DWORD)model.Audio.size());
			if (FAILED(hr)) {
				_com_error err(hr);
				LOG_ERROR(L"Writing of audio sample with start pos %lld ms failed: %s", (HundredNanosToMillis(model.AudioStartPos)), err.ErrorMessage());
				return hr;//Stop recording if we fail
			}
			else {
				wroteAudioSample = true;
			}
		}
		auto frameInfoStr = wroteAudioSample ? (model.PaddedBytes > 0 ? L"video sample and audio padding" : L"video and audio sample") : L"video sample";
		LOG_TRACE(L"Wrote %s with video: %lldms + %.2fms, audio: %lldms + %.2fms, diff: %.2fms.",
			frameInfoStr,
			HundredNanosToMillis(model.VideoStartPos),
			HundredNanosToMillisDouble(model.VideoDuration),
			HundredNanosToMillis(model.AudioStartPos),
			HundredNanosToMillisDouble(model.AudioDuration),
			HundredNanosToMillisDouble((model.VideoStartPos + model.VideoDuration) - (model.AudioStartPos + model.AudioDuration)));
	}
	else if (recorderMode == RecorderModeInternal::Slideshow) {
		wstring	path = m_OutputFolder + L"\\" + to_wstring(m_TimelineManager->GetRenderedVideoFrameCount()) + GetSnapshotOptions()->GetImageExtension();
		hr = WriteFrameToImage(model.Frame, path);
		INT64 startposMs = HundredNanosToMillis(model.VideoStartPos);
		INT64 durationMs = HundredNanosToMillis(model.VideoDuration);
		if (FAILED(hr)) {
			_com_error err(hr);
			LOG_ERROR(L"Writing of slideshow frame with start pos %lld ms failed: %s", startposMs, err.ErrorMessage());
			return hr; //Stop recording if we fail
		}
		else {

			m_FrameDelays.insert(std::pair<wstring, int>(path, startposMs == 0 ? 0 : (int)durationMs));
			LOG_TRACE(L"Wrote slideshow frame with start pos %lld ms and with duration %lld ms", startposMs, durationMs);
		}
	}
	else if (recorderMode == RecorderModeInternal::Screenshot) {
		if (m_OutStream) {
			hr = WriteFrameToImage(model.Frame, m_OutStream);
			LOG_TRACE(L"Wrote snapshot to stream");
		}
		else {
			hr = WriteFrameToImage(model.Frame, m_OutputFullPath);
			LOG_TRACE(L"Wrote snapshot to %s", m_OutputFullPath.c_str());
		}
	}
	return hr;
}

HRESULT OutputManager::WriteFrameToImage(_In_ ID3D11Texture2D *pAcquiredDesktopImage, _In_ std::wstring filePath)
{
	return SaveWICTextureToFile(m_DeviceContext, pAcquiredDesktopImage, GetSnapshotOptions()->GetSnapshotEncoderFormat(), filePath.c_str());
}
HRESULT OutputManager::WriteFrameToImage(_In_ ID3D11Texture2D *pAcquiredDesktopImage, _In_ IStream *pStream)
{
	return SaveWICTextureToStream(m_DeviceContext, pAcquiredDesktopImage, GetSnapshotOptions()->GetSnapshotEncoderFormat(), pStream);
}


HRESULT OutputManager::ConfigureOutputMediaTypes(
	_In_ UINT destWidth,
	_In_ UINT destHeight,
	_Outptr_ IMFMediaType **pVideoMediaTypeOut,
	_Outptr_result_maybenull_ IMFMediaType **pAudioMediaTypeOut)
{
	*pVideoMediaTypeOut = nullptr;
	*pAudioMediaTypeOut = nullptr;
	CComPtr<IMFMediaType> pVideoMediaType = nullptr;
	CComPtr<IMFMediaType> pAudioMediaType = nullptr;
	// Set the output video type.
	RETURN_ON_BAD_HR(MFCreateMediaType(&pVideoMediaType));
	RETURN_ON_BAD_HR(pVideoMediaType->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Video));
	RETURN_ON_BAD_HR(pVideoMediaType->SetGUID(MF_MT_SUBTYPE, GetEncoderOptions()->GetVideoEncoderFormat()));
	RETURN_ON_BAD_HR(pVideoMediaType->SetUINT32(MF_MT_AVG_BITRATE, GetEncoderOptions()->GetVideoBitrate()));
	RETURN_ON_BAD_HR(pVideoMediaType->SetUINT32(MF_MT_INTERLACE_MODE, MFVideoInterlace_Progressive));
	RETURN_ON_BAD_HR(pVideoMediaType->SetUINT32(MF_MT_MPEG2_PROFILE, GetEncoderOptions()->GetEncoderProfile()));
	RETURN_ON_BAD_HR(pVideoMediaType->SetUINT32(MF_MT_VIDEO_PRIMARIES, MFVideoPrimaries_BT709));
	RETURN_ON_BAD_HR(pVideoMediaType->SetUINT32(MF_MT_YUV_MATRIX, MFVideoTransferMatrix_BT709));
	RETURN_ON_BAD_HR(pVideoMediaType->SetUINT32(MF_MT_TRANSFER_FUNCTION, MFVideoTransFunc_709));
	RETURN_ON_BAD_HR(MFSetAttributeSize(pVideoMediaType, MF_MT_FRAME_SIZE, destWidth, destHeight));
	RETURN_ON_BAD_HR(MFSetAttributeRatio(pVideoMediaType, MF_MT_FRAME_RATE, GetEncoderOptions()->GetVideoFps(), 1));
	RETURN_ON_BAD_HR(MFSetAttributeRatio(pVideoMediaType, MF_MT_PIXEL_ASPECT_RATIO, 1, 1));

	if (GetAudioOptions()->IsAudioEnabled()) {
		// Set the output audio type.
		RETURN_ON_BAD_HR(MFCreateMediaType(&pAudioMediaType));
		RETURN_ON_BAD_HR(pAudioMediaType->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Audio));
		RETURN_ON_BAD_HR(pAudioMediaType->SetGUID(MF_MT_SUBTYPE, GetAudioOptions()->GetAudioEncoderFormat()));
		RETURN_ON_BAD_HR(pAudioMediaType->SetUINT32(MF_MT_AUDIO_NUM_CHANNELS, GetAudioOptions()->GetAudioChannels()));
		RETURN_ON_BAD_HR(pAudioMediaType->SetUINT32(MF_MT_AUDIO_BITS_PER_SAMPLE, GetAudioOptions()->GetAudioBitsPerSample()));
		RETURN_ON_BAD_HR(pAudioMediaType->SetUINT32(MF_MT_AUDIO_SAMPLES_PER_SECOND, GetAudioOptions()->GetAudioSamplesPerSecond()));
		RETURN_ON_BAD_HR(pAudioMediaType->SetUINT32(MF_MT_AUDIO_AVG_BYTES_PER_SECOND, GetAudioOptions()->GetAudioBitrate()));

		*pAudioMediaTypeOut = pAudioMediaType;
		(*pAudioMediaTypeOut)->AddRef();
	}

	*pVideoMediaTypeOut = pVideoMediaType;
	(*pVideoMediaTypeOut)->AddRef();
	return S_OK;
}

HRESULT OutputManager::ConfigureInputMediaTypes(
	_In_ UINT sourceWidth,
	_In_ UINT sourceHeight,
	_In_ MFVideoRotationFormat rotationFormat,
	_In_ IMFMediaType *pVideoMediaTypeOut,
	_Outptr_ IMFMediaType **pVideoMediaTypeIn,
	_Outptr_result_maybenull_ IMFMediaType **pAudioMediaTypeIn)
{
	*pVideoMediaTypeIn = nullptr;
	*pAudioMediaTypeIn = nullptr;
	CComPtr<IMFMediaType> pVideoMediaType = nullptr;
	CComPtr<IMFMediaType> pAudioMediaType = nullptr;

	RETURN_ON_BAD_HR(MFCreateMediaType(&pVideoMediaType));
	RETURN_ON_BAD_HR(pVideoMediaType->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Video));
	RETURN_ON_BAD_HR(pVideoMediaType->SetGUID(MF_MT_SUBTYPE, MFVideoFormat_ARGB32));
	// Uncompressed means all samples are independent.
	RETURN_ON_BAD_HR(pVideoMediaType->SetUINT32(MF_MT_ALL_SAMPLES_INDEPENDENT, TRUE));
	RETURN_ON_BAD_HR(pVideoMediaType->SetUINT32(MF_MT_VIDEO_ROTATION, rotationFormat));
	RETURN_ON_BAD_HR(pVideoMediaType->SetUINT32(MF_MT_INTERLACE_MODE, MFVideoInterlace_Progressive));
	RETURN_ON_BAD_HR(pVideoMediaType->SetUINT32(MF_MT_VIDEO_PRIMARIES, MFVideoPrimaries_BT709));
	RETURN_ON_BAD_HR(pVideoMediaType->SetUINT32(MF_MT_YUV_MATRIX, MFVideoTransferMatrix_BT709));
	RETURN_ON_BAD_HR(pVideoMediaType->SetUINT32(MF_MT_TRANSFER_FUNCTION, MFVideoTransFunc_709));
	RETURN_ON_BAD_HR(MFSetAttributeSize(pVideoMediaType, MF_MT_FRAME_SIZE, sourceWidth, sourceHeight));
	if (!GetEncoderOptions()->IsFixedFramerate()) {
		RETURN_ON_BAD_HR(MFSetAttributeRatio(pVideoMediaType, MF_MT_FRAME_RATE, GetEncoderOptions()->GetVideoFps(), 1));
	}
	RETURN_ON_BAD_HR(MFSetAttributeRatio(pVideoMediaType, MF_MT_PIXEL_ASPECT_RATIO, 1, 1));

	if (GetAudioOptions()->IsAudioEnabled()) {
		// Set the input audio type.
		RETURN_ON_BAD_HR(MFCreateMediaType(&pAudioMediaType));
		RETURN_ON_BAD_HR(pAudioMediaType->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Audio));
		RETURN_ON_BAD_HR(pAudioMediaType->SetGUID(MF_MT_SUBTYPE, MFAudioFormat_PCM));
		RETURN_ON_BAD_HR(pAudioMediaType->SetUINT32(MF_MT_AUDIO_BITS_PER_SAMPLE, GetAudioOptions()->GetAudioBitsPerSample()));
		RETURN_ON_BAD_HR(pAudioMediaType->SetUINT32(MF_MT_AUDIO_SAMPLES_PER_SECOND, GetAudioOptions()->GetAudioSamplesPerSecond()));
		RETURN_ON_BAD_HR(pAudioMediaType->SetUINT32(MF_MT_AUDIO_NUM_CHANNELS, GetAudioOptions()->GetAudioChannels()));

		*pAudioMediaTypeIn = pAudioMediaType;
		(*pAudioMediaTypeIn)->AddRef();
	}

	*pVideoMediaTypeIn = pVideoMediaType;
	(*pVideoMediaTypeIn)->AddRef();
	return S_OK;
}

HRESULT OutputManager::InitializeVideoSinkWriter(
	_In_ IMFByteStream *pOutStream,
	_In_ RECT sourceRect,
	_In_ SIZE outputFrameSize,
	_In_ DXGI_MODE_ROTATION rotation,
	_In_ IMFSinkWriterCallback *pCallback,
	_Outptr_ IMFSinkWriter **ppWriter,
	_Out_ DWORD *pVideoStreamIndex,
	_Out_ DWORD *pAudioStreamIndex)
{
	*ppWriter = nullptr;
	*pVideoStreamIndex = 0;
	*pAudioStreamIndex = 0;

	CComPtr<IMFSinkWriter>        pSinkWriter = nullptr;
	CComPtr<IMFMediaType>         pVideoMediaTypeOut = nullptr;
	CComPtr<IMFMediaType>         pAudioMediaTypeOut = nullptr;
	CComPtr<IMFMediaType>         pVideoMediaTypeIn = nullptr;
	CComPtr<IMFMediaType>		  pVideoMediaTypeIntermediate = nullptr;
	CComPtr<IMFMediaType>		  pVideoMediaTypeTransform = nullptr;
	CComPtr<IMFMediaType>         pAudioMediaTypeIn = nullptr;
	CComPtr<IMFAttributes>        pAttributes = nullptr;

	MFVideoRotationFormat rotationFormat = MFVideoRotationFormat_0;
	if (rotation == DXGI_MODE_ROTATION_ROTATE90) {
		rotationFormat = MFVideoRotationFormat_90;
	}
	else if (rotation == DXGI_MODE_ROTATION_ROTATE180) {
		rotationFormat = MFVideoRotationFormat_180;
	}
	else if (rotation == DXGI_MODE_ROTATION_ROTATE270) {
		rotationFormat = MFVideoRotationFormat_270;
	}

	DWORD videoStreamIndex = 0;
	DWORD audioStreamIndex = 1;

	UINT sourceWidth = RectWidth(sourceRect);
	UINT sourceHeight = RectHeight(sourceRect);

	UINT destWidth = max(0l, outputFrameSize.cx);
	UINT destHeight = max(0l, outputFrameSize.cy);

	RETURN_ON_BAD_HR(ConfigureOutputMediaTypes(destWidth, destHeight, &pVideoMediaTypeOut, &pAudioMediaTypeOut));
	RETURN_ON_BAD_HR(ConfigureInputMediaTypes(sourceWidth, sourceHeight, rotationFormat, pVideoMediaTypeOut, &pVideoMediaTypeIn, &pAudioMediaTypeIn));

	//The source samples have the format ARGB32, but the video encoders need the input to be a YUV format, so we convert ARGB32->NV12->H264/HEVC
	CopyMediaType(pVideoMediaTypeIn, &pVideoMediaTypeIntermediate);
	RETURN_ON_BAD_HR(pVideoMediaTypeIntermediate->SetGUID(MF_MT_SUBTYPE, MFVideoFormat_NV12));
	CopyMediaType(pVideoMediaTypeIntermediate, &pVideoMediaTypeTransform);
	pVideoMediaTypeTransform->DeleteItem(MF_MT_FRAME_RATE);

	RETURN_ON_BAD_HR(CreateIMFTransform(videoStreamIndex, pVideoMediaTypeIn, pVideoMediaTypeTransform, &m_MediaTransform));

	CComPtr<IMFAttributes> pTransformAttributes;
	if (SUCCEEDED(m_MediaTransform->GetAttributes(&pTransformAttributes))) {
		UINT32 d3d11Aware = 0;
		pTransformAttributes->GetUINT32(MF_SA_D3D11_AWARE, &d3d11Aware);
		if (d3d11Aware > 0) {
			HRESULT hr = m_MediaTransform->ProcessMessage(MFT_MESSAGE_SET_D3D_MANAGER, reinterpret_cast<ULONG_PTR>(m_DeviceManager.p));
			LOG_ON_BAD_HR(hr);
		}
	}

	//Creates a streaming writer
	CComPtr<IMFMediaSink> pMp4StreamSink = nullptr;
	if (GetEncoderOptions()->IsFragmentedMp4Enabled()) {
		RETURN_ON_BAD_HR(MFCreateFMPEG4MediaSink(pOutStream, pVideoMediaTypeOut, pAudioMediaTypeOut, &pMp4StreamSink));
	}
	else {
		RETURN_ON_BAD_HR(MFCreateMPEG4MediaSink(pOutStream, pVideoMediaTypeOut, pAudioMediaTypeOut, &pMp4StreamSink));
	}
	pAudioMediaTypeOut.Release();

	RETURN_ON_BAD_HR(MFCreateAttributes(&pAttributes, 7));
	RETURN_ON_BAD_HR(pAttributes->SetGUID(MF_TRANSCODE_CONTAINERTYPE, GetEncoderOptions()->IsFragmentedMp4Enabled() ? MFTranscodeContainerType_FMPEG4 : MFTranscodeContainerType_MPEG4));
	RETURN_ON_BAD_HR(pAttributes->SetUINT32(MF_READWRITE_ENABLE_HARDWARE_TRANSFORMS, GetEncoderOptions()->IsHardwareEncodingEnabled()));
	RETURN_ON_BAD_HR(pAttributes->SetUINT32(MF_MPEG4SINK_MOOV_BEFORE_MDAT, GetEncoderOptions()->IsFastStartEnabled()));
	RETURN_ON_BAD_HR(pAttributes->SetUINT32(MF_LOW_LATENCY, GetEncoderOptions()->IsLowLatencyModeEnabled()));
	RETURN_ON_BAD_HR(pAttributes->SetUINT32(MF_SINK_WRITER_DISABLE_THROTTLING, GetEncoderOptions()->IsThrottlingDisabled()));
	RETURN_ON_BAD_HR(pAttributes->SetUINT32(CODECAPI_AVEncCommonRateControlMode, GetEncoderOptions()->GetVideoBitrateMode()));
	switch (GetEncoderOptions()->GetVideoBitrateMode()) {
		case eAVEncCommonRateControlMode_Quality:
			RETURN_ON_BAD_HR(pAttributes->SetUINT32(CODECAPI_AVEncCommonQuality, GetEncoderOptions()->GetVideoQuality()));
			break;
		default:
			break;
	}
	// Add device manager to attributes. This enables hardware encoding.
	RETURN_ON_BAD_HR(pAttributes->SetUnknown(MF_SINK_WRITER_D3D_MANAGER, m_DeviceManager));
	RETURN_ON_BAD_HR(pAttributes->SetUnknown(MF_SINK_WRITER_ASYNC_CALLBACK, pCallback));

	RETURN_ON_BAD_HR(MFCreateSinkWriterFromMediaSink(pMp4StreamSink, pAttributes, &pSinkWriter));
	pMp4StreamSink.Release();

	LOG_TRACE("Input video format:")
		LogMediaType(pVideoMediaTypeIn);
	LOG_TRACE("Converted video format:")
		LogMediaType(pVideoMediaTypeIntermediate);
	LOG_TRACE("Output video format:")
		LogMediaType(pVideoMediaTypeOut);

	HRESULT hr = pSinkWriter->SetInputMediaType(videoStreamIndex, m_UseManualNV12Converter ? pVideoMediaTypeIntermediate : pVideoMediaTypeIn, nullptr);
	if ((FAILED(hr) && !m_UseManualNV12Converter)) {
		m_UseManualNV12Converter = true;
		m_MediaTransform.Release();

		return InitializeVideoSinkWriter(pOutStream, sourceRect, outputFrameSize, rotation, pCallback, ppWriter, pVideoStreamIndex, pAudioStreamIndex);
	}
	RETURN_ON_BAD_HR(hr);
	if (pAudioMediaTypeIn) {
		RETURN_ON_BAD_HR(pSinkWriter->SetInputMediaType(audioStreamIndex, pAudioMediaTypeIn, nullptr));
	}

	// Tell the sink writer to start accepting data.
	RETURN_ON_BAD_HR(pSinkWriter->BeginWriting());

	// Return the pointer to the caller.
	*ppWriter = pSinkWriter;
	(*ppWriter)->AddRef();
	*pVideoStreamIndex = videoStreamIndex;
	*pAudioStreamIndex = audioStreamIndex;
	return S_OK;
}

HRESULT OutputManager::WriteFrameToVideo(_In_ INT64 frameStartPos, _In_ INT64 frameDuration, _In_ DWORD streamIndex, _In_ ID3D11Texture2D *pAcquiredDesktopImage)
{
	//The encoder works async, so the input frame has to be copied, else it can be overwritten before the encoder uses it. See issue #277.
	CComPtr<ID3D11Texture2D> pFrameCopy;
	D3D11_TEXTURE2D_DESC desc;
	pAcquiredDesktopImage->GetDesc(&desc);
	m_Device->CreateTexture2D(&desc, nullptr, &pFrameCopy);
	m_DeviceContext->CopyResource(pFrameCopy, pAcquiredDesktopImage);

	IMFMediaBuffer *pMediaBuffer;
	HRESULT hr = MFCreateDXGISurfaceBuffer(__uuidof(ID3D11Texture2D), pFrameCopy, 0, FALSE, &pMediaBuffer);
	IMF2DBuffer *p2DBuffer;
	if (SUCCEEDED(hr))
	{
		hr = pMediaBuffer->QueryInterface(__uuidof(IMF2DBuffer), reinterpret_cast<void **>(&p2DBuffer));
	}
	DWORD length;
	if (SUCCEEDED(hr))
	{
		hr = p2DBuffer->GetContiguousLength(&length);
	}
	if (SUCCEEDED(hr))
	{
		hr = pMediaBuffer->SetCurrentLength(length);
	}
	IMFSample *pSample;
	if (SUCCEEDED(hr))
	{
		hr = MFCreateSample(&pSample);
	}
	if (SUCCEEDED(hr))
	{
		hr = pSample->AddBuffer(pMediaBuffer);
	}
	if (SUCCEEDED(hr))
	{
		hr = pSample->SetSampleTime(frameStartPos);
	}
	if (SUCCEEDED(hr))
	{
		hr = pSample->SetSampleDuration(frameDuration);
	}

	if (SUCCEEDED(hr))
	{
		if (m_UseManualNV12Converter) {
			//Run media transform to convert sample to MFVideoFormat_NV12

			MFT_OUTPUT_STREAM_INFO info{};

			hr = m_MediaTransform->GetOutputStreamInfo(streamIndex, &info);
			bool transformProvidesSamples = info.dwFlags & (MFT_OUTPUT_STREAM_PROVIDES_SAMPLES | MFT_OUTPUT_STREAM_CAN_PROVIDE_SAMPLES);

			IMFSample *transformSample = nullptr;
			IMFMediaBuffer *transformBuffer = nullptr;
			MFT_OUTPUT_DATA_BUFFER outputDataBuffer;
			RtlZeroMemory(&outputDataBuffer, sizeof(outputDataBuffer));
			outputDataBuffer.dwStreamID = streamIndex;
			{
				if (SUCCEEDED(hr) && !transformProvidesSamples)
				{
					hr = MFCreateMemoryBuffer(info.cbSize, &transformBuffer);

					if (SUCCEEDED(hr))
					{
						hr = MFCreateSample(&transformSample);
					}
					if (SUCCEEDED(hr)) {
						hr = transformSample->AddBuffer(transformBuffer);
					}
					outputDataBuffer.pSample = transformSample;
					SafeRelease(&transformBuffer);
				}
				if (SUCCEEDED(hr))
				{
					hr = m_MediaTransform->ProcessInput(streamIndex, pSample, 0);
				}
				if (SUCCEEDED(hr))
				{
					DWORD dwDSPStatus = 0;
					hr = m_MediaTransform->ProcessOutput(0, 1, &outputDataBuffer, &dwDSPStatus);
				}
				if (SUCCEEDED(hr)) {
					transformSample = outputDataBuffer.pSample;
				}
			}
			if (SUCCEEDED(hr))
			{
				hr = transformSample->SetSampleTime(frameStartPos);
			}
			if (SUCCEEDED(hr))
			{
				hr = transformSample->SetSampleDuration(frameDuration);
			}
			if (SUCCEEDED(hr))
			{
				hr = m_SinkWriter->WriteSample(streamIndex, transformSample);
			}
			SafeRelease(&transformSample);
		}
		else {
			hr = m_SinkWriter->WriteSample(streamIndex, pSample);
		}
	}
	SafeRelease(&pSample);
	SafeRelease(&p2DBuffer);
	SafeRelease(&pMediaBuffer);
	return hr;
}

HRESULT OutputManager::WriteAudioSamplesToVideo(_In_ INT64 frameStartPos, _In_ INT64 frameDuration, _In_ DWORD streamIndex, _In_ const BYTE *pSrc, _In_ DWORD cbData)
{
	IMFMediaBuffer *pBuffer = nullptr;
	BYTE *pData = nullptr;
	// Create the media buffer.
	HRESULT hr = MFCreateMemoryBuffer(
		cbData,   // Amount of memory to allocate, in bytes.
		&pBuffer
	);
	// Lock the buffer to get a pointer to the memory.
	if (SUCCEEDED(hr))
	{
		hr = pBuffer->Lock(&pData, nullptr, nullptr);
	}

	if (SUCCEEDED(hr))
	{
		memcpy_s(pData, cbData, pSrc, cbData);
	}

	// Update the current length.
	if (SUCCEEDED(hr))
	{
		hr = pBuffer->SetCurrentLength(cbData);
	}

	// Unlock the buffer.
	if (pData)
	{
		hr = pBuffer->Unlock();
	}

	IMFSample *pSample = nullptr;
	if (SUCCEEDED(hr))
	{
		hr = MFCreateSample(&pSample);
	}
	if (SUCCEEDED(hr))
	{
		hr = pSample->AddBuffer(pBuffer);
	}
	if (SUCCEEDED(hr))
	{
		INT64 start = frameStartPos;
		hr = pSample->SetSampleTime(start);
	}
	if (SUCCEEDED(hr))
	{
		INT64 duration = frameDuration;
		hr = pSample->SetSampleDuration(duration);
	}
	if (SUCCEEDED(hr))
	{
		// Send the sample to the Sink Writer.
		hr = m_SinkWriter->WriteSample(streamIndex, pSample);
	}
	SafeRelease(&pSample);
	SafeRelease(&pBuffer);
	return hr;
}