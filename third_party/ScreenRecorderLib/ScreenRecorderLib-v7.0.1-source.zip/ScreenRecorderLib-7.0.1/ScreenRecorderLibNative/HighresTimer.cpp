#include "HighresTimer.h"
#include "Log.h"

using namespace std::chrono;
using namespace std;
HighresTimer::HighresTimer() :
	m_TimerResolution(0),
	m_TickEvent(nullptr),
	m_StopEvent(nullptr),
	m_EventArray{},
	m_LastTick(0),
	m_Interval(0),
	m_TickCount(0),
	m_IsActive(false)
{
	TIMECAPS tc;
	UINT targetResolutionMs = 1;
	if (timeGetDevCaps(&tc, sizeof(TIMECAPS)) == TIMERR_NOERROR)
	{
		m_TimerResolution = min(max(tc.wPeriodMin, targetResolutionMs), tc.wPeriodMax);
		timeBeginPeriod(m_TimerResolution);
	}
	//CREATE_WAITABLE_TIMER_HIGH_RESOLUTION is an undocumented flag introduced in Windows 10 1803.
	//CreateWaitableTimerEx returns NULL if not available.
	m_TickEvent = CreateWaitableTimerEx(NULL, NULL, CREATE_WAITABLE_TIMER_HIGH_RESOLUTION, TIMER_ALL_ACCESS);
	if (m_TickEvent == NULL) {
		m_TickEvent = CreateWaitableTimer(NULL, false, NULL);
	}
	m_StopEvent = CreateEvent(nullptr, TRUE, FALSE, nullptr);
	HANDLE eventArray[2]{ m_StopEvent ,m_TickEvent };

	m_EventArray[0] = m_StopEvent;
	m_EventArray[1] = m_TickEvent;
}

HighresTimer::~HighresTimer()
{
	if (m_TimerResolution > 0) {
		timeEndPeriod(m_TimerResolution);
	}
	CloseHandle(m_TickEvent);
	CloseHandle(m_StopEvent);
}

HRESULT HighresTimer::StartRecurringTimer(INT64 msInterval)
{
	if (NULL == m_TickEvent) {
		DWORD dwErr = GetLastError();
		LOG_ERROR(L"CreateWaitableTimer failed: last error = %u", dwErr);
		return HRESULT_FROM_WIN32(dwErr);
	}

	m_Interval = msInterval;
	ResetEvent(m_TickEvent);
	ResetEvent(m_StopEvent);

	QueryPerformanceCounter((LARGE_INTEGER *)&m_LastTick);

	LARGE_INTEGER liFirstFire;
	liFirstFire.QuadPart = -0; // negative means relative time
	BOOL bOK = SetWaitableTimer(
		m_TickEvent,
		&liFirstFire,
		static_cast<LONG>(msInterval),
		NULL, NULL, FALSE
	);
	if (!bOK) {
		DWORD dwErr = GetLastError();
		LOG_ERROR(L"SetWaitableTimer failed on OnReadSample: last error = %u", dwErr);
		return HRESULT_FROM_WIN32(dwErr);
	}
	m_IsActive = true;
	return S_OK;
}

HRESULT HighresTimer::StopTimer(bool waitForCompletion)
{
	SetEvent(m_StopEvent);
	if (waitForCompletion && m_IsActive) {
		if (WaitForSingleObject(m_TickEvent, INFINITE) != WAIT_OBJECT_0) {
			LOG_ERROR("Failed to wait for timer tick");
			return E_FAIL;
		}
	}
	m_IsActive = false;
	CancelWaitableTimer(m_TickEvent);
	LOG_DEBUG("Stopped HighresTimer");
	return S_OK;
}

HRESULT HighresTimer::WaitForNextTick()
{
	//WAIT_OBJECT_0 means the first handle in the array, the stop event, signaled the stop, so exit.
	if (WaitForMultipleObjects(ARRAYSIZE(m_EventArray), m_EventArray, FALSE, INFINITE) == WAIT_OBJECT_0) {
		LOG_TRACE("HighresTimer was canceled");
		return E_FAIL;
	}

	QueryPerformanceCounter((LARGE_INTEGER *)&m_LastTick);
	m_TickCount++;
	return S_OK;
}

HRESULT HighresTimer::WaitFor(INT64 interval100Nanos)
{
	LARGE_INTEGER liFirstFire;
	liFirstFire.QuadPart = -interval100Nanos; // negative means relative time
	BOOL bOK = SetWaitableTimer(
		m_TickEvent,
		&liFirstFire,
		0,
		NULL, NULL, FALSE
	);
	if (!bOK) {
		LOG_ERROR(L"HighresTimer::WaitFor failed setting timer");
		return E_FAIL;
	}
	m_IsActive = true;
	//WAIT_OBJECT_0 means the first handle in the array, the stop event, signaled the stop, so exit.
	if (WaitForMultipleObjects(ARRAYSIZE(m_EventArray), m_EventArray, FALSE, INFINITE) == WAIT_OBJECT_0) {
		LOG_TRACE("HighresTimer was canceled");
		m_IsActive = false;
		return E_FAIL;
	}
	m_IsActive = false;
	QueryPerformanceCounter((LARGE_INTEGER *)&m_LastTick);
	m_TickCount++;
	return S_OK;
}

INT64 HighresTimer::GetMillisUntilNextTick()
{
	if (m_TickCount == 0)
		return 0;
	INT64 now{};
	QueryPerformanceCounter((LARGE_INTEGER *)&now);
	return max(0ll, (m_Interval - HundredNanosToMillis(now - m_LastTick)));
}